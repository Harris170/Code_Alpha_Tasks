﻿#pragma execution_character_set("utf-8")
#include <windows.h>
#include <iostream>
#include <print>
#include <string>
#include <vector>
#include <fstream>

#define VERSION 0.97
#define SAVE_FILE "Todos"

// Console Colors //
#define reset		"\033[0m"
#define red			"\033[31m"
#define green		"\033[32m"
#define yellow		"\033[33m"
#define blue        "\033[34m"
#define orange      "\033[38;5;208m"

#define reset_bg	"\x1b[49m"
#define red_bg		"\x1b[41m"
#define green_bg	"\x1b[42m"
#define yellow_bg	"\x1b[43m"

// Helper Utility Types and Functions //
typedef enum
{
	no_error = 0,
	invalid_command,
	incomplete_command,
	invalid_item
} Error;

static void OK(const std::string message) { std::println("{} ✓ {} {}{}{}", green_bg, reset, green, message, reset); }
static void WRN(const std::string message) { std::println("{} ! {} {}{}{}", yellow_bg, reset, yellow, message, reset); }
static void ERR(const std::string message) { std::println("{} ⨯ {} {}{}{}", red_bg, reset, red, message, reset); }

[[nodiscard]] std::vector<std::string_view> SplitString(std::string& string, const char* delimiter = " ")
{
	std::vector<std::string_view> args;
	char* next = nullptr;
	char* token = strtok_s(string.data(), delimiter, &next);
	while (token != nullptr)
	{
		args.push_back(token);
		token = strtok_s(nullptr, delimiter, &next);
	}
	return args;
}
[[nodiscard]] std::string SplitStringView(std::vector<std::string_view>& original, std::string& left_side, const char* delimiter = " ")
{
	bool found = false;
	std::vector<std::string_view> temp = original;
	uint64_t i = 0;
	for (auto it = original.begin(); it != original.end(); ++it)
	{
		if (original.at(i) != delimiter)
		{
			left_side += std::string(original.at(i));
			left_side += " ";
		}

		if (strcmp(it->data(), delimiter) == 0)
		{
			found = true;
			temp.erase(temp.begin());
			break;
		}
		temp.erase(temp.begin());
		i++;
	}
	std::string right_side = "";
	for (auto& s : temp)
	{
		right_side += s;
		right_side += " ";
	}
	left_side.pop_back();  // removing extra space at the end
	if (found and right_side.size() > 0) right_side.pop_back(); // removing extra space at the end if strings were provided after the delimiter
	return right_side;
}
static void PrintError(Error& error)
{
	if (error != Error::no_error)
	{
		std::print("\n");
		switch (error)
		{
		case invalid_command: ERR("Invalid command. Type 'h' or '?' for help."); break;
		case incomplete_command: ERR("Incomplete command."); break;
		case invalid_item: ERR("Item is invalid."); break;
		case no_error: break;
		default: break;
		}
		std::print("\n");
	}
	error = Error::no_error; // error was printed, so we reset //
}
void ReadLn(std::string& line)
{
	std::print("{}ToDo ➤{} ", blue, reset);
	std::getline(std::cin, line);
}

////////////////////////////////////////////

typedef struct item_t
{
public:
	typedef enum
	{
		inactive = 0,
		done,
		waiting,
		in_progress
	} status;

	item_t(uint64_t p_id, std::string p_name, std::string p_description = "", item_t::status p_status = item_t::status::waiting)
		: id(p_id)
		, m_name(p_name)
		, m_description(p_description)
		, m_status(p_status) {}

	item_t& SetName(std::string p_name) { m_name = p_name; return *this; }
	item_t& SetDescription(std::string p_description) { m_description = p_description; return *this; }
	item_t& SetStatus(item_t::status p_status) { m_status = p_status; return *this; }

	[[nodiscard]] std::string GetName() const { return m_name; }
	[[nodiscard]] std::string GetDescription() const { return m_description; }
	[[nodiscard]] item_t::status GetStatus() const { return m_status; }
	[[nodiscard]] std::string GetStatusString() const
	{
		switch (m_status)
		{
		case status::inactive: return std::string("Inactive");
		case status::done: return std::string("Done");
		case status::waiting: return std::string("Waiting");
		case status::in_progress: return std::string("In Progress");
		default: return std::string("");
		}
	}
	[[nodiscard]] uint64_t GetID() const { return id; }

private:
	uint64_t id;
	std::string m_name;
	std::string m_description;
	status m_status;
} Item;

class ToDo
{
private:
	uint64_t uid;
	Item invalid_item = Item(0, "", "", Item::inactive);
	std::vector<Item> m_items;
public:
	ToDo()
		: uid(1)
	{}
	[[nodiscard]] uint64_t Size() const { return m_items.size(); }
	[[nodiscard]] uint64_t SizeOfItemsWithStatus(const Item::status p_status) const
	{
		uint64_t size = 0;
		for (auto it = m_items.begin(); it != m_items.end(); ++it)
		{
			if (it->GetStatus() == p_status) size += 1;
		}
		return size;
	}
	void Add(std::string p_name, std::string p_description = "", Item::status p_status = Item::waiting)
	{
		m_items.push_back(Item(uid, p_name, p_description, p_status));
		uid += 1;
		OK("Added [" + p_name + "]");
	}
	bool Remove(const Item p_item)
	{
		for (auto it = m_items.begin(); it != m_items.end(); ++it)
		{
			if (it->GetID() == p_item.GetID())
			{
				std::string name = it->GetName();
				m_items.erase(it);
				OK("Removed [" + name + "]");
				return true;
			}
		}
		ERR("Could not remove item.");
		return false;
	}
	bool Remove(const uint64_t id)
	{
		if (id == 0)
		{
			ERR("Cannot remove at index 0");
			return false;
		}
		for (auto it = m_items.begin(); it != m_items.end(); ++it)
		{
			if (it->GetID() == id)
			{
				std::string name = it->GetName();
				m_items.erase(it);
				OK("Removed [" + name + "]");
				return true;
			}
		}
		ERR("Could not remove item.");
		return false;
	}
	[[nodiscard]] uint64_t GetUID() const { return uid; }
	void ResetUID() { uid = 1; this->m_items[0].SetStatus(Item::inactive); }

	[[nodiscard]] Item& GetItemWith(const std::string p_name)
	{
		for (auto it = m_items.begin(); it != m_items.end(); ++it)
		{
			if (it->GetName() == p_name)
			{
				return *it;
			}
		}
		return invalid_item;
	}
	[[nodiscard]] Item& GetItemWith(const uint64_t p_id)
	{
		for (auto it = m_items.begin(); it != m_items.end(); ++it)
		{
			if (it->GetID() == p_id)
			{
				return *it;
			}
		}
		return invalid_item;
	}
	[[nodiscard]] Item& GetItemAt(const uint64_t index)
	{
		return m_items[index];
	}
};

int main()
{
	SetConsoleOutputCP(CP_UTF8);
	std::unique_ptr<ToDo> todo = std::make_unique<ToDo>();
	Error error = Error::no_error;
	bool quit = false;
	std::string line;
	std::vector<std::string_view> args;

	while (not quit)
	{
		system("cls");
		std::println("\t\t\t     |==] {}ToDo List{} v{} [==|\n", orange, reset, VERSION);
		std::print("\t{}[{}] Waiting{} \t|\t", red, todo->SizeOfItemsWithStatus(Item::waiting), reset);
		std::print("{}[{}] In Progress{} \t|\t", yellow, todo->SizeOfItemsWithStatus(Item::in_progress), reset);
		std::println("{}[{} / {}] Done ({} Left) {}", green, todo->SizeOfItemsWithStatus(Item::done), todo->Size(), todo->Size() - todo->SizeOfItemsWithStatus(Item::done), reset);

		PrintError(error);
		ReadLn(line);

		if (line.size() <= 0) continue;
		args = SplitString(line);
		if (args[0].starts_with("h") or args[0].starts_with("?"))
		{
			std::println("Input commands when the {}ToDo ➤{} is visible. Otherwise press Enter to continue.", blue, reset);
			std::println("Parameters in {}[ ]{} are {}mandatory{}.", blue, reset, blue, reset);
			std::println("Parameters in ( ) are optional.");
			std::println("All commands need to be written in one line, including their parameters, with spaces.");
			std::println("\nCommands:");
			std::println("h or ?\t \t\tShow this command list.");
			std::println("q    \t \t\tQuit program.");
			std::println("t {}[name]{} -d (desc)\tAdd new task. Description (optional) can also be provided.", blue, reset);
			std::println("r {}[ID]{}\t \t\tRemove task.", blue, reset);
			std::println("s (d or p or w)\t\tShows the tasks. Providing d/p/w will only show the tasks with that status.");
			std::println("{}d {}[ID]{} ...\t\tSet task as {}Done{}. Multiple IDs can be provided inline.", green, blue, reset, green, reset);
			std::println("{}p {}[ID]{} ...\t\tSet task as {}In Progress{}. Multiple IDs can be provided inline.", yellow, blue, reset, yellow, reset);
			std::println("{}w {}[ID]{} ...\t\tSet task as {}Waiting{}. Multiple IDs can be provided inline.", red, blue, reset, red, reset);
		}
		else if (args[0].starts_with("q"))
		{
			if (todo->Size() <= 0) exit(0);

			std::vector<Item> waiting_items;
			std::vector<Item> in_progress_items;
			std::vector<Item> done_items;

			// Sorting Items //
			for (uint64_t i = 1; i <= todo->Size(); i++)
			{
				Item& item = todo->GetItemWith(i);
				switch (item.GetStatus())
				{
				case Item::waiting: waiting_items.push_back(item); continue;
				case Item::in_progress: in_progress_items.push_back(item); continue;
				case Item::done: done_items.push_back(item); continue;
				case Item::inactive:continue;
				default: continue;
				}
			}
			std::ofstream save_file(SAVE_FILE + std::string(".md"));
			if (save_file.is_open())
			{
				if (todo->SizeOfItemsWithStatus(Item::waiting) > 0)
				{
					// Print Waiting Items //
					save_file << "### Waiting" << std::endl;
					for (auto& item : waiting_items)
					{
						save_file << std::endl << "- " << item.GetName() << std::endl;
						if (item.GetDescription() != "") save_file << "`" << item.GetDescription() << "`" << std::endl;
					}
				}

				if (todo->SizeOfItemsWithStatus(Item::in_progress) > 0)
				{
					// Print In Progress Items //
					save_file << "\n___" << std::endl;
					save_file << "### In Progress" << std::endl;
					for (auto& item : in_progress_items)
					{
						save_file << std::endl << "- " << item.GetName() << std::endl;
						if (item.GetDescription() != "") save_file << "`" << item.GetDescription() << "`" << std::endl;
					}
					save_file << "___\n" << std::endl;
				}

				if (todo->SizeOfItemsWithStatus(Item::done) > 0)
				{
					// Print Done Items //
					save_file << "### Done" << std::endl;
					for (auto& item : done_items)
					{
						save_file << "\n- ~~" << item.GetName();
						if (item.GetDescription() != "") save_file << "\n`" << item.GetDescription() << "`";
						save_file << "~~\n";
					}
					// removing the last endl that was written by last task from the file //
					save_file.seekp(-2, std::ios_base::end);
				}
				save_file.close();
			}
			else
			{
				ERR(std::string("\nCould not save the todos. Are you sure you want to") + red + "exit ?" + reset + " (y / n)");
				ReadLn(line);
				if (line == "n" or line == "N") continue;
				else if (line == "y" or line == "Y") exit(0);
				else continue;
			}
			exit(0);
		}
		else if (args[0].starts_with("r"))
		{
			if (args.size() < 2)
			{
				error = Error::incomplete_command;
				continue;
			}

			if (todo->Size() <= 0) continue;
			if (args[1].starts_with("all"))
			{
				std::println("Are you sure you want to {}remove all tasks?{} (y/n)", red, reset);
				std::string choice;
				ReadLn(choice);
				if (choice == "n" or choice == "N") continue;
				else if (choice == "y" or choice == "Y")
				{
					todo = std::make_unique<ToDo>();
					OK("All tasks removed.");
				}
				else continue;
			}
			else
			{
				todo->Remove(stoull(std::string(args[1])));
			}
		}
		else if (args[0].starts_with("s"))
		{
			if (todo->Size() <= 0) continue;
			if (args.size() <= 0) continue;

			std::string spacer = " | ";
			uint64_t i = 0;
			if (args.size() > 1)
			{
				if (args[1].starts_with("d"))
				{
					while (i < todo->Size())
					{
						Item& item = todo->GetItemAt(i++);
						if (item.GetDescription() == "") spacer = "";
						if (item.GetStatus() == Item::done)
						{
							std::println("{}[{}] {}{}{}{}", green, item.GetID(), item.GetName(), spacer, item.GetDescription(), reset);
							continue;
						}
					}
				}
				else if (args[1].starts_with("w"))
				{
					while (i < todo->Size())
					{
						Item& item = todo->GetItemAt(i++);
						if (item.GetDescription() == "") spacer = "";
						if (item.GetStatus() == Item::waiting)
						{
							std::println("{}[{}] {}{}{}{}", red, item.GetID(), item.GetName(), spacer, item.GetDescription(), reset);
							continue;
						}
					}
				}
				else if (args[1].starts_with("p"))
				{
					while (i < todo->Size())
					{
						Item& item = todo->GetItemAt(i++);
						if (item.GetDescription() == "") spacer = "";
						if (item.GetStatus() == Item::in_progress)
						{
							std::println("{}[{}] {}{}{}{}", yellow, item.GetID(), item.GetName(), spacer, item.GetDescription(), reset);
							continue;
						}
					}
				}
				else
				{
					error = Error::invalid_command;
					continue;
				}
			}
			else
			{
				while (i < todo->Size())
				{
					Item& item = todo->GetItemAt(i++);
					if (item.GetDescription() == "") spacer = "";
					else spacer = " | ";
					switch (item.GetStatus())
					{
					case Item::waiting: {
						std::println("{}[{}] {}{}{}{}", red, item.GetID(), item.GetName(), spacer, item.GetDescription(), reset);
						continue;
					}
					case Item::in_progress:
					{
						std::println("{}[{}] {}{}{}{}", yellow, item.GetID(), item.GetName(), spacer, item.GetDescription(), reset);
						continue;
					}
					case Item::done:
					{
						std::println("{}[{}] {}{}{}{}", green, item.GetID(), item.GetName(), spacer, item.GetDescription(), reset);
						continue;
					}
					case Item::inactive: continue;
					default: continue;
					}
				}
			}
		}
		else if (args[0].starts_with("d"))
		{
			if (args.size() < 2)
			{
				error = Error::incomplete_command;
				continue;
			}
			if (todo->Size() <= 0) continue;

			if (args.size() == 1)
			{
				Item& item = todo->GetItemWith(stoull(std::string(args[1])));
				if (item.GetStatus() == Item::inactive)
				{
					error = Error::invalid_item;
					continue;
				}
				if (item.GetStatus() == Item::done)
					WRN(std::string("Task [") + item.GetName() + "] " + "is already " + green + "done" + reset + ".");
				else
				{
					item.SetStatus(Item::done);
					OK(std::string("Set task [") + item.GetName() + "] to Done");
				}
			}
			else
			{
				for (uint64_t i = 1; i < args.size(); i++)
				{
					Item& item = todo->GetItemWith(stoull(std::string(args[i])));
					if (item.GetStatus() == Item::inactive)
					{
						error = Error::invalid_item;
						continue;
					}
					if (item.GetStatus() == Item::done)
						WRN(std::string("Task [") + item.GetName() + "] " + "is already " + green + "done" + reset + ".");
					else
					{
						item.SetStatus(Item::done);
						OK(std::string("Set task [") + item.GetName() + "] to Done");
					}
				}
			}
		}
		else if (args[0].starts_with("p"))
		{
			if (args.size() < 2)
			{
				error = Error::incomplete_command;
				continue;
			}
			if (todo->Size() <= 0) continue;

			if (args.size() == 1)
			{
				Item& item = todo->GetItemWith(stoull(std::string(args[1])));
				if (item.GetStatus() == Item::inactive)
				{
					error = Error::invalid_item;
					continue;
				}
				if (item.GetStatus() == Item::done)
					WRN(std::string("Task [") + item.GetName() + "] " + "is already in progress.");
				else
				{
					item.SetStatus(Item::in_progress);
					OK(std::string("Set task [") + item.GetName() + "] to " + yellow + "In Progress." + reset);
				}
			}
			else
			{
				for (uint64_t i = 1; i < args.size(); i++)
				{
					Item& item = todo->GetItemWith(stoull(std::string(args[i])));
					if (item.GetStatus() == Item::inactive)
					{
						error = Error::invalid_item;
						continue;
					}
					if (item.GetStatus() == Item::in_progress)
						WRN(std::string("Task [") + item.GetName() + "] " + "is already in progress.");
					else
					{
						item.SetStatus(Item::in_progress);
						OK(std::string("Set task [") + item.GetName() + "] to " + yellow + "In Progress." + reset);
					}
				}
			}
		}
		else if (args[0].starts_with("w"))
		{
			if (args.size() < 2)
			{
				error = Error::incomplete_command;
				continue;
			}
			if (todo->Size() <= 0) continue;

			if (args.size() == 1)
			{
				Item& item = todo->GetItemWith(stoull(std::string(args[1])));
				if (item.GetStatus() == Item::inactive)
				{
					error = Error::invalid_item;
					continue;
				}
				if (item.GetStatus() == Item::waiting)
					WRN(std::string("Task [") + item.GetName() + "] " + "is already " + red + "waiting" + reset + ".");
				else
				{
					item.SetStatus(Item::waiting);
					OK(std::string("Set task [") + item.GetName() + "] to " + red + "Waiting." + reset);
				}
			}
			else
			{
				for (uint64_t i = 1; i < args.size(); i++)
				{
					Item& item = todo->GetItemWith(stoull(std::string(args[i])));
					if (item.GetStatus() == Item::inactive)
					{
						error = Error::invalid_item;
						continue;
					}
					if (item.GetStatus() == Item::waiting)
						WRN(std::string("Task [") + item.GetName() + "] " + "is already " + red + "waiting" + reset + ".");
					else
					{
						item.SetStatus(Item::waiting);
						OK(std::string("Set task [") + item.GetName() + "] to " + red + "Waiting." + reset);
					}
				}
			}
		}
		else if (args[0].starts_with("t"))
		{
			if (args.size() < 2 or args[1] == "-d")
			{
				error = Error::incomplete_command;
				continue;
			}

			args.erase(args.begin());
			std::string name;
			std::string description = SplitStringView(args, name, "-d");
			if (description.size() == 0)
				todo->Add(name);
			else
				todo->Add(name, description);
		}
		else
		{
			error = Error::invalid_command;
			continue;
		}
		std::cin.get();
	}
	return 0;
}